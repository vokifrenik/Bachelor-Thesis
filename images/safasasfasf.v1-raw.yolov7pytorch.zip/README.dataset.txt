# safasasfasf > raw
https://universe.roboflow.com/vicente-hernandez-g-mail-pucv-cl/safasasfasf

Provided by a Roboflow user
License: CC BY 4.0

